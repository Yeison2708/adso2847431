<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List All Users</title>
</head>
<body class=
            "bg-teal-800
            text-teal-200
            flex
            flex-col
            gap-8
            justify-center
            min-h-[100dvh]
            items-center"> 
    <h1 class=
                "font-bold 
                border-b-2
                text-4xl">
                List All Users 
                <small class=
                "text-teal-400 
                text-lg">
                Factory challenge
                </small>
            </h1>
            
            <section 
            class= "users 
                    grid 
                    grid-cols-2
                    sm:grid-cols-3
                    md:grid-cols-5
                    gap-2">

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class=
                    "bg-teal-700 
                    flex-col
                    flex
                    p-4 
                    rounded-lg
                    justify-center
                    items-center
                    ">
                    <img src="<?php echo e(asset('images/'.$user->photo)); ?> "width="100px" height="100px " class="rounded-full" alt="User Photo">
                    <h2 class=
                        "font-bold 
                        text-lg 
                        text-center">
                        <?php echo e($user->fullname); ?>

                    </h2>
                    <h3 class=
                            "text-sm text-center">
                        <?php echo e($user->role); ?>

                    </h3>
                    <p class=
                        "text-sm text-center">
                        <?php echo e($user->gender); ?>

                    </p>
                    <p class=
                        "text-sm text-center">
                        <?php echo e($user->birthdate); ?>

                    </p>
                    <p class=
                        "text-sm text-center">
                        <?php echo e($user->email); ?>

                    </p>
                    <p class=
                        "text-sm text-center">
                        <?php echo e($user->phone); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </section>


    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</body>
</html><?php /**PATH C:\Users\yeiso\adso2847431\03-laravel\petsapp\resources\views/users-factory.blade.php ENDPATH**/ ?>